var searchData=
[
  ['canvas',['canvas',['../class_q_rcode.html#a036166ee2cabf2089f0d7744f0e5b7ab',1,'QRcode']]],
  ['changelog',['CHANGELOG',['../md__c_h_a_n_g_e_l_o_g.html',1,'']]]
];
