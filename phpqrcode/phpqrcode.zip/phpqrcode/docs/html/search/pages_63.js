var searchData=
[
  ['changelog',['CHANGELOG',['../md__c_h_a_n_g_e_l_o_g.html',1,'']]]
];
