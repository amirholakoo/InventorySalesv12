var searchData=
[
  ['getcode',['getCode',['../class_q_rrawcode.html#ac689de00987140f351dc2dc96d4468cc',1,'QRrawcode']]],
  ['getdatalength',['getDataLength',['../class_q_rspec.html#a1383f2d578a23a3086ad9e0be6f54733',1,'QRspec']]],
  ['getecclength',['getECCLength',['../class_q_rspec.html#a82a8dd01287901cc540fe36f323c3082',1,'QRspec']]],
  ['getframeat',['getFrameAt',['../class_q_rframe_filler.html#abde0811d7b30cbd94926a37771a624d8',1,'QRframeFiller']]],
  ['getminimumversion',['getMinimumVersion',['../class_q_rspec.html#a352c2a30f35805dd6c872e5b7ae4923e',1,'QRspec']]],
  ['getremainder',['getRemainder',['../class_q_rspec.html#ad63500d0c855f2ca98e956081d3a89c5',1,'QRspec']]],
  ['getwidth',['getWidth',['../class_q_rspec.html#a6cd893740237966f1c37aa4a8a0ef4de',1,'QRspec']]]
];
