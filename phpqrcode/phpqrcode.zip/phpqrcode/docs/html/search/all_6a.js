var searchData=
[
  ['jpg',['jpg',['../class_q_rimage.html#a94780a8e078f441e8b48689e79972010',1,'QRimage']]]
];
