var searchData=
[
  ['global_20constants',['Global Constants',['../group___q_r___c_o_n_s_t.html',1,'']]],
  ['global_20config',['Global Config',['../group___q_r___d_e_f_c_o_n_f_i_g_s.html',1,'']]]
];
