var searchData=
[
  ['png',['png',['../class_q_rcode.html#a1b90c0989105afa06b6e1c718a454fb5',1,'QRcode\png()'],['../class_q_rimage.html#a93d33067f3db2597523974a673ea0661',1,'QRimage\png()']]],
  ['putalignmentmarker',['putAlignmentMarker',['../class_q_rspec.html#a42ea00fd9ba26c421c690a19da3d2a42',1,'QRspec']]],
  ['putfinderpattern',['putFinderPattern',['../class_q_rspec.html#add4d1d16648b00be6105861418d6f946',1,'QRspec']]]
];
