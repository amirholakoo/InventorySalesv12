HOW TO BUILD YOUR OWN DOCS
==========================

* download Doxygen ZIP from: http://www.stack.nl/~dimitri/doxygen/download.html
* unpack all *.exe files here
* run generate.bat